# Using flask to make an api
# import necessary libraries and functions
from flask import Flask
from flask import jsonify
from flask import request
import csv
# creating a Flask app
app = Flask(__name__)
  
# on the terminal type: curl http://127.0.0.1:5000/
# returns hello world when we use GET.
# returns all data save in inventory.csv file
@app.route('/', methods = ['GET'])
def home():
    """
    function  to return all the data in json format
    eg: http://127.0.0.1:5000/
    """
    if(request.method == 'GET'):
        di = []
        with open('inventory.csv', 'r') as csv_file:
            reader = csv.reader(csv_file)
            for row in reader:
                di.append(row)
        data = "address"
        return jsonify({'address': di })
  
  

@app.route('/search', methods=['GET'])
def search():
    """
    function to search for particular ip addr
    eg: http://127.0.0.1:5000/search?addr=10.1.1.1
    """
    if(request.method == 'GET'):
        args = request.args
        addr = args.get('addr')
        di = []
        with open('inventory.csv', 'r') as csv_file:
            reader = csv.reader(csv_file)
            for row in reader:
                if len(row):
                    di.append(row)
            for attr in di:
                if addr in attr:
                    return jsonify({'data': attr})
            else:
                return "No Rows Matched"
  
# driver function
if __name__ == '__main__':
    app.run(debug = True)